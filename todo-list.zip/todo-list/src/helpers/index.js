import {createBrowserHistory} from 'history'

export const toDoHistory=createBrowserHistory();