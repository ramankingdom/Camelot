export const TODOCONSTANTS = {
    ToDo_GetList_Request: "ToDo_GetList_Request",
    ToDo_GetList_Sucess: "ToDo_GetList_Sucess",
    ToDo_NewToDo_Request: "ToDo_NewToDo_Request",
    ToDo_Delete_Request: "ToDo_Delete_Request",
    ToDo_Complete_Request: "ToDo_Complete_Request",
    ToDo_GetSingle_Request: "ToDo_GetSingle_Request",
    ToDo_GetSingle_Sucess: "ToDo_GetSingle_Sucess",
    ToDo_Submit_Request: "ToDo_Submit_Request",
    ToDo_Change_Request: "ToDo_Change_Request",
  };
  